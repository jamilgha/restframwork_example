from django.contrib import admin
from .models import movie,moviegender
# Register your models here.
admin.site.register(movie)
admin.site.register(moviegender)